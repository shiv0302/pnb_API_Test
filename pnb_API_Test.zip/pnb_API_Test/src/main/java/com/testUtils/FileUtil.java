package com.testUtils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileUtil {
	private static final String CONFIG_FILE_PATH="src/main/resources/apiConfig/configuration.properties";
	static Logger log = LoggerFactory.getLogger(FileUtil.class);
	
	public static Map<String,String> getConfigProperties(){
		return readProperties(CONFIG_FILE_PATH);
	}
	
	public static Map<String,String> readProperties(final String path) {
		Properties prop = readAndReturnProperties(path);
		Map<String, String> propMap = new HashMap<>();
		for(Entry<Object, Object> entries : prop.entrySet()){
			propMap.put((String) entries.getKey(), (String) entries.getValue());
		}
		return propMap;
	}
	
	public static Properties readAndReturnProperties(final String path){
		Properties prop = new Properties();
		InputStream input = null;
		try{
			input= new FileInputStream(path);
			prop.load(input);
		}
		catch(Exception e){
			log.info("Exception while reading properties file: "+e.getMessage());
		}
		finally{
			try{
				if(input!=null)
					input.close();
			}
			catch(Exception e){
				log.info("Exception while closing the properties file: "+e.getMessage());
			}
		}
		return prop;
	}
}
