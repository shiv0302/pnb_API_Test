package com.testUtils;

import org.testng.annotations.DataProvider;

public class DataProviderUtil {

	@DataProvider (name = "CreateUserData")
	 public static Object[][] createUserData(){
	 return new Object[][] {{"Jhon","worker","user"}
	 , {"Sam","manager","CEO"}
	 , {"Samuel","leader","manger"}
	, {"Mark","Sr manager","Sr Tester"}
	 , {"Jim","Tester","Developer"}};
	 }
}
