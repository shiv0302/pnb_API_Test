package apiTesting;

import java.util.Map;
import static io.restassured.RestAssured.given;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.testUtils.DataProviderUtil;
import com.testUtils.FileReader;
import com.testUtils.FileUtil;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;


public class TestAPI {
	Logger log = LoggerFactory.getLogger(Test.class);
	private static Configuration configuration = Configuration.defaultConfiguration();
	String hostUrl,endPoint, endPointWithParam, requestCreateUser, requestUpdateUser;
	Map<String,String> configProps;
	
	@BeforeClass
	public void beforeClass() throws Exception{
		configProps =FileUtil.getConfigProperties();
		hostUrl = configProps.get("baseURL");
		endPoint = configProps.get("endPoint");
		endPointWithParam = configProps.get("endPointWithParam");
		requestCreateUser = new FileReader().readFile("requests/createUser.json");
		RestAssured.useRelaxedHTTPSValidation();
		
	}
	
	@Test(enabled=true, dataProvider="CreateUserData", dataProviderClass = DataProviderUtil.class)
	public void task1(String name, String job, String updatedJob) throws Exception{
		try{
			createUser(name, job);
			getSingleUser();
			updateUser(name, updatedJob);
			String userResponse = getUsers();
			Assert.assertTrue(userResponse.contains(name)&&userResponse.contains(updatedJob));
		}
		catch(Exception e){
			Assert.fail("Exception while calling all methods "+e.getMessage());
		}
	}
	
	@Test(enabled=true, dataProvider="CreateUserData", dataProviderClass = DataProviderUtil.class)
	public void task2(String name, String job, String updatedJob) throws Exception{
		try{
			deleteUser();
			String userResponse = getUsers();
			Assert.assertFalse(userResponse.contains(name)&&userResponse.contains(updatedJob));
		}
		catch(Exception e){
			Assert.fail("Exception while calling all methods "+e.getMessage());
		}
	}
	
	@Test(enabled=true)
	public void task3() throws Exception{
		long startTime = System.currentTimeMillis();
		long endTime = 0;
		try{
			delayUsers("30");
			endTime = System.currentTimeMillis();
			Assert.assertTrue((startTime-endTime)==30.0);
		}
		catch(Exception e){
			Assert.fail("Exception while calling all methods "+e.getMessage());
		}
	}
	
	public void createUser(String name, String job) throws Exception{
		try{
			DocumentContext requestBody;
			requestBody = JsonPath.using(configuration).parse(requestCreateUser);
			requestBody.set("$.name", name);
			requestBody.set("$.job",job);
			given().basePath(endPoint)
			.baseUri(hostUrl)
			.accept(ContentType.JSON)
			.body(requestBody.jsonString())
			.log().all()
			.when()
			.post()
			.then()
			.log().all()
			.and()
			.assertThat()
			.statusCode(HttpStatus.SC_OK);
		}
		catch(Exception e){
			Assert.fail("Exception thrown while creating the user - "+e.getMessage());
		}
	}
	
	public String getUsers() throws Exception{
		String response="";
		try{	
			 response = given().basePath(endPoint)
			.baseUri(hostUrl)
			.queryParam("page", "2")
			.log().all()
			.when()
			.get()
			.then()
			.log().all()
			.and()
			.assertThat()
			.statusCode(HttpStatus.SC_OK).and().extract().response().asString();
			System.out.println(response);
		}
		catch(Exception e){
			Assert.fail("Exception thrown while creating the user - "+e.getMessage());
		}
		return response;
	}
	
	public void getSingleUser() throws Exception{
		try{
			given().basePath(endPointWithParam)
			.baseUri(hostUrl)
			.pathParam("param", "2")
			.log().all()
			.when()
			.get()
			.then()
			.log().all()
			.and()
			.assertThat()
			.statusCode(HttpStatus.SC_OK);
		}
		catch(Exception e){
			Assert.fail("Exception thrown while creating the user - "+e.getMessage());
		}
	}
	
	public void updateUser(String name, String job) throws Exception{
		try{
			DocumentContext requestBody;
			requestBody = JsonPath.using(configuration).parse(requestCreateUser);
			requestBody.set("$.name", name);
			requestBody.set("$.job",job);
			given().basePath(endPoint)
			.baseUri(hostUrl)
			.accept(ContentType.JSON)
			.body(requestBody.jsonString())
			.log().all()
			.when()
			.patch()
			.then()
			.log().all()
			.and()
			.assertThat()
			.statusCode(HttpStatus.SC_OK);
		}
		catch(Exception e){
			Assert.fail("Exception thrown while creating the user - "+e.getMessage());
		}
	}
	
	public void deleteUser() throws Exception{
		try{
			given().basePath(endPointWithParam)
			.baseUri(hostUrl)
			.accept(ContentType.JSON)
			.param("param", "2")
			.log().all()
			.when()
			.delete()
			.then()
			.log().all()
			.and()
			.assertThat()
			.statusCode(HttpStatus.SC_OK);
		}
		catch(Exception e){
			Assert.fail("Exception thrown while creating the user - "+e.getMessage());
		}
	}
	
	public void delayUsers(String delay) throws Exception{
		try{
			String response = given().basePath(endPointWithParam)
			.baseUri(hostUrl)
			.accept(ContentType.JSON)
			.queryParam("delay", delay)
			.log().all()
			.when()
			.get()
			.then()
			.log().all()
			.and()
			.assertThat()
			.statusCode(HttpStatus.SC_OK).and().extract().response().asString();
			System.out.println(response);
		}
		catch(Exception e){
			Assert.fail("Exception thrown while creating the user - "+e.getMessage());
		}
	}

}
